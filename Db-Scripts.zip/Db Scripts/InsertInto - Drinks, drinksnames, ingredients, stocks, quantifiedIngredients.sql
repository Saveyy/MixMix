insert into Ingredients values('Rom', 1, 85)
insert into Ingredients values('Red Bull', 1, 0)
insert into Ingredients values('Cola', 1, 0)
insert into Ingredients values('J�germeister', 1, 35)
insert into Ingredients values('Lime', 0, 0)

insert into Measurements values('skiver', null)
insert into Measurements values('cl', 1)

insert into Drinks values ('Bland Rom og Cola og l�g en lime i')
insert into Drinks values ('Bland J�germeister og Red Bull')
insert into Drinks values ('H�ld Rom op')

--Cuba Libre
--Rom
insert into QuantifiedIngredients values(4, 1, 2, 1)
--Cola
insert into QuantifiedIngredients values(12, 3, 2, 1)
--Lime
insert into QuantifiedIngredients values(1, 5, 1, 1)

--J�gerblast
--J�germeister
insert into QuantifiedIngredients values(12, 4, 2, 2)
--Red Bull
insert into QuantifiedIngredients values(12, 2, 2, 2)

--Bare Rom
--Rom
insert into QuantifiedIngredients values(8, 1, 2, 3)

--Cuba Libre
insert into DrinkNames values('Cuba Libre', 1)
insert into DrinkNames values('Cuba Rom,Cola,Lime', 1)

--J�gerblast
insert into DrinkNames values('J�gerblast', 2)
insert into DrinkNames values('Starter', 2)

--Bare Rom
insert into DrinkNames values('Rom', 3)
insert into DrinkNames values('Bare Rom', 3)

--Bar1
insert into Stocks values(6, 1, 1)
insert into Stocks values(200, 3, 1)
insert into Stocks values(5, 5, 1)
insert into Stocks values(200, 4, 1)
insert into Stocks values(200, 2, 1)