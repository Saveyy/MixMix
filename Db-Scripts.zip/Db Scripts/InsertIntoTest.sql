
insert into Countries values('Danmark');
insert into Zipcodes values('8800', 'Viborg', 1);
insert into Addresses values('Hvidtj�rnen 6', 1);
insert into Managers values('Nikolaj S�rensen', '28944200', 'Bettelej@gmail.com', 'Bettelej', '123456789', '987654321');
insert into Bars values('Nikos', '88888888', 'Bar@gmail.com', 'BarUser', '123456789', '987654321', 1, 1);
insert into Ingredients values('Vodka', 1, 37);
insert into Stocks values(2, 1, 1);

--select * from Stocks where bar_ID = 1 and ingredient_ID = 1;