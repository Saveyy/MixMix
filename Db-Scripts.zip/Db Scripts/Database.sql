-- drop if necessary, then create "MixMix"
use master;
if exists (select * from sys.databases where name='MixMix')
	drop database MixMix;
go

create database MixMix;
go

use MixMix;

create table Countries(
id int primary key identity(1,1),
name varchar(100) not null unique
);

create table Zipcodes(
id int primary key identity(1,1),
zipcode varchar(100)not null,
name varchar(100)not null,
country_ID int not null,
foreign key(country_ID) references Countries(id)
);

create table Addresses(
id int primary key identity(1,1),
name varchar(100) not null,
zipcode_ID int not null,
foreign key(zipcode_ID) references Zipcodes(id)
);

create table Managers(
id int primary key identity(1,1),
name varchar(100) not null,
phonenumber varchar(100) not null unique,
email varchar(100) not null,
username varchar(100) not null unique,
hashedPassword varchar(44) not null,
salt varchar(44) not null
);

create table Customers(
id int primary key identity(1,1),
name varchar(100) not null,
phonenumber varchar(100) not null,
email varchar(100) not null,
username varchar(100) not null unique,
hashedPassword varchar(44) not null,
salt varchar(44) not null
);

create table Bars(
id int primary key identity(1,1),
name varchar(100) not null,
phonenumber varchar(100) not null unique,
email varchar(100) not null unique,
username varchar(100) not null unique,
hashedPassword varchar(44) not null,
salt varchar(44) not null,
address_ID int not null,
manager_ID int not null,
foreign key(address_ID) references Addresses(id),
foreign key(manager_ID) references Managers(id)
);

create table Events(
id int primary key identity(1,1),
name varchar(100) not null,
description varchar(2000) not null,
startDate DateTime not null,
endDate DateTime not null,
bar_ID int not null,
constraint fk_event_bar foreign key(bar_ID) references Bars(id)
on delete cascade
);

create table Ingredients(
id int primary key identity(1,1),
name varchar(100) not null,
measurable bit not null,
alchVol float not null
);

create table Stocks(
quantity float not null check (quantity >= 0),
ingredient_ID int not null,
bar_ID int not null,
constraint fk_stock_ingredient foreign key(ingredient_ID) references Ingredients(id)
on delete cascade,
constraint fk_stock_bar foreign key(bar_ID) references Bars(id)
on delete cascade,
primary key(ingredient_ID, bar_ID)
);

create table Prices(
sellingPrice decimal not null,
byingPrice decimal,
ingredient_ID int not null,
bar_ID int not null,
constraint fk_price_ingredient foreign key(ingredient_ID) references Ingredients(id)
on delete cascade,
constraint fk_price_bar foreign key(bar_ID) references Bars(id)
on delete cascade,
primary key(ingredient_ID, bar_ID)
);

create table Measurements(
id int primary key identity(1,1),
type varchar(100) not null unique,
proportion float
);

create table Drinks(
id int primary key identity(1,1),
recipe varchar(2000) not null
);

create table QuantifiedIngredients(
id int primary key identity(1,1),
quantity float not null,
ingredient_ID int not null,
measurement_ID int not null,
drink_ID int not null,
constraint fk_quantifiedIngredient_ingredient foreign key(ingredient_ID) references Ingredients(id)
on delete cascade,
constraint fk_quantifiedIngredient_measurement foreign key(measurement_ID) references Measurements(id)
on delete cascade,
constraint fk_quantifiedIngredient_drink foreign key(drink_ID) references Drinks(id)
on delete cascade
);

create table DrinkNames(
id int primary key identity(1,1),
name varChar(100) not null unique,
drink_ID int not null,
constraint fk_drinkName_drink foreign key(drink_ID) references Drinks(id)
on delete cascade
);

--Denne sekvens er lavet fordi man ikke kan lave to identity i et table. Det er ca. det samme.
CREATE SEQUENCE ID_sequence
    START WITH 3
    INCREMENT BY 3;
GO

create table Orders(
id int primary key identity(1,1),
orderNumber int not null  DEFAULT (NEXT VALUE FOR ID_sequence),
orderTime DateTime not null,
deliveryTime DateTime,
status varchar(100) not null,
bar_ID int,
customer_ID int,
constraint fk_order_bar foreign key(bar_ID) references Bars(id)
on delete set null,
constraint fk_order_customer foreign key(customer_ID) references Customers(id)
on delete set null
);

create table OrderLines(
id int primary key identity(1,1),
quantity int not null,
subtotal decimal not null,
drink_ID int,
order_ID int not null,
constraint fk_orderLine_drink foreign key(drink_ID) references Drinks(id)
on delete set null,
constraint fk_orderLine_order foreign key(order_ID) references Orders(id)
on delete cascade
);

create table Offers(
id int primary key identity(1,1),
discount decimal not null,
startTime DateTime not null,
endTime DateTime not null,
discountType varchar(100) not null,
drink_ID int,
ingredient_ID int,
bar_ID int not null,
constraint fk_offer_drink foreign key(drink_ID) references Drinks(id)
on delete cascade,
constraint fk_offer_ingredient foreign key(ingredient_ID) references Ingredients(id)
on delete cascade,
constraint fk_offer_bar foreign key(bar_ID) references Bars(id)
on delete cascade
);

create table Specialties(
drink_ID int not null,
bar_ID int not null,
constraint fk_specialtie_drink foreign key(drink_ID) references Drinks(id)
on delete cascade,
constraint fk_specialtie_bar foreign key(bar_ID) references Bars(id)
on delete cascade,
primary key(drink_ID, bar_ID)
);

create table Favorites(
drink_ID int not null,
customer_ID int not null,
constraint fk_favorite_drink foreign key(drink_ID) references Drinks(id)
on delete cascade,
constraint fk_favorite_customer foreign key(customer_ID) references Customers(id)
on delete cascade,
primary key(drink_ID, customer_ID)
);