insert into Countries values('Danmark');
insert into Countries values('Tyskland');
insert into Countries values('Frankrig');
insert into Countries values('Spanien');

insert into Zipcodes values('8800', 'Viborg', 1);
insert into Zipcodes values('9000', 'Aalborg', 1);
insert into Zipcodes values('7400', 'Herning', 1);
insert into Zipcodes values('2730', 'Herlev', 1);
insert into Zipcodes values('9830', 'T�rs', 1);

insert into Addresses values('Konvalvej 41, 2. th.', 2);
insert into Addresses values('Hvidtj�rnen 6', 1);
insert into Addresses values('Ole R�mersvej 15, st. th.', 3);
insert into Addresses values('Herlevvej', 4);
insert into Addresses values('T�rsvej', 5);

insert into Managers values('Jonas', '11111111', 'Jonas@Jonas.Jonas', 'Jonas', '1234', '1234')
insert into Managers values('Mikkel', '22222222', 'Mikkel@Mikkel.Mikkel', 'Mikkel', '1234', '1234')
insert into Managers values('Fisk', '33333333', 'Fisk@Fisk.Fisk', 'Fisk', '1234', '1234')
insert into Managers values('Mads', '44444444', 'Mads@Mads.Mads', 'Mads', '1234', '1234')
insert into Managers values('Nikolaj', '55555555', 'Nikolaj@Nikolaj.Nikolaj', 'Nikolaj', '1234', '1234')

insert into Bars values('bar1', '11111111','1@1', 'bar1username', '1234', '1234', 2, 1);
insert into Bars values('bar2', '22222222','2@2', 'bar2username', '1234', '1234', 2, 2);
insert into Bars values('bar3', '33333333','3@3', 'bar3username', '1234', '1234', 2, 2);
insert into Bars values('bar4', '44444444','4@4', 'bar4username', '1234', '1234', 2, 4);
insert into Bars values('bar5', '55555555','5@5', 'bar5username', '1234', '1234', 1, 1);
insert into Bars values('bar6', '66666666','6@6', 'bar6username', '1234', '1234', 1, 2);
insert into Bars values('bar7', '77777777','7@7', 'bar7username', '1234', '1234', 1, 2);
insert into Bars values('bar8', '88888888','8@8', 'bar8username', '1234', '1234', 1, 4);
insert into Bars values('bar9', '99999999','9@9', 'bar9username', '1234', '1234', 3, 1);
insert into Bars values('bar10', '10101010','10@10', 'bar10username', '1234', '1234', 4, 2);
insert into Bars values('bar11', '12345678','11@11', 'bar11username', '1234', '1234', 4, 2);
insert into Bars values('bar12', '87654231','12@12', 'bar12username', '1234', '1234', 5, 4);