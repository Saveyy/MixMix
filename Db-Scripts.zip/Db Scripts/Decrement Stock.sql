--CREATE PROCEDURE DecrementStock(@BarId int, @DrinkId int)

--AS
UPDATE
    Stocks
SET
    Stocks.quantity = s.quantity - qfi.quantity
FROM
    Stocks AS s
    INNER JOIN QuantifiedIngredients AS qfi
        ON s.ingredient_ID = qfi.ingredient_ID
		inner join Ingredients as I
		on I.id = s.ingredient_ID
WHERE
    s.bar_ID = @BarId
	and qfi.drink_ID = @DrinkId
	and I.measurable = 1 --Skal rent faktisk v�re 1(true)
