CREATE PROCEDURE FindAllAvailableDrinks(@BarId int)

AS

declare @DrinkId int
declare @OutputTable table
(
QFIquantity int,
type varchar(100),
name varchar(100),
drinkID int
)

declare DrinkCursor cursor local static read_only Forward_only
for
select distinct id from Drinks

declare @expected int, @found int

open DrinkCursor
Fetch next from DrinkCursor into @DrinkId
while @@FETCH_STATUS=0
Begin

set @expected = 
(select count(QFI.drink_ID) from QuantifiedIngredients QFI where QFI.drink_ID = @DrinkId)

set @found =
(select count(*) from (select A.QFIquantity AQFIquantity from (select QFI.quantity QFIquantity
from QuantifiedIngredients QFI, Measurements M, Ingredients I, Bars B, Stocks S, Drinks D
where B.id = S.bar_ID and S.ingredient_ID=I.id and QFI.measurement_ID=M.id
 and QFI.ingredient_ID=I.id and D.id=QFI.drink_ID and S.quantity >= QFI.quantity and B.id = @BarId
 and D.id=@DrinkId) A) ID)

if @expected = @found
insert into @OutputTable select QFI.quantity QFIquantity, M.type, I.name, D.id drinkID
from QuantifiedIngredients QFI, Measurements M, Ingredients I, Bars B, Stocks S, Drinks D
where B.id = S.bar_ID and S.ingredient_ID=I.id and QFI.measurement_ID=M.id
 and QFI.ingredient_ID=I.id and D.id=QFI.drink_ID and S.quantity >= QFI.quantity and B.id = @BarId
 and D.id=@DrinkId
 
fetch next from DrinkCursor into @DrinkId
End

close DrinkCursor
deallocate DrinkCursor

select * from @OutputTable;
select distinct D.id, Dn.name from DrinkNames DN, Drinks D, @OutputTable o where DN.drink_ID=D.id and dn.drink_ID=o.drinkID and D.id=o.drinkID;




